$(document).ready(function(){
	$('.gallery').slick({
		dots: true,
		arrows: true,
		infinite: true,
		speed: 500,
		fade: true,
		adaptiveHeight: true,
		centerMode: true
});
});