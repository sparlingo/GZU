<<<<<<< HEAD
default_app_config = 'blog.apps.BlogConfig'
=======
"""
Package for the application.
"""
>>>>>>> 85acd7fbad963838039669bf0ed322c70a83b68e
