from django.contrib import admin
from .models import Post, Comment, Feedback, Question, Choice, Vote

class ChoiceInLine(admin.TabularInline):
	model = Choice
	extra = 3
	
class QuestionAdmin(admin.ModelAdmin):
	fieldsets = [
	('Question to ask', {'fields': ['question_text', 'question_reference']}),
<<<<<<< HEAD
	('Date information', {'fields': ['pub_date', 'expire_date']}),
=======
	('Date information', {'fields': ['pub_date']}),
>>>>>>> 85acd7fbad963838039669bf0ed322c70a83b68e
	]
	inlines = [ChoiceInLine]

admin.site.register(Post)
admin.site.register(Comment)
admin.site.register(Feedback)
admin.site.register(Choice)
<<<<<<< HEAD
admin.site.register(Question, QuestionAdmin)
=======
admin.site.register(Question, QuestionAdmin)
>>>>>>> 85acd7fbad963838039669bf0ed322c70a83b68e
