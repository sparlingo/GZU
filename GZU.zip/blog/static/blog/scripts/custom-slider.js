$("#ex1").slider();
$("#ex1").on("slide", function(slideEvt) {
	$("#ex1SliderVal").text(slideEvt.value);
});
$("#ex2").slider();
$("#ex2").on("slide", function(slideEvt) {
	$("#ex2SliderVal").text(slideEvt.value);
});
$("#ex3").slider();
$("#ex3").on("slide", function(slideEvt) {
	$("#ex3SliderVal").text(slideEvt.value);
});
$("#ex4").slider();
$("#ex4").on("slide", function(slideEvt) {
	$("#ex4SliderVal").text(slideEvt.value);
});
$("#ex5").slider();
$("#ex5").on("slide", function(slideEvt) {
	$("#ex5SliderVal").text(slideEvt.value);
});
$("#ex6").slider();
$("#ex6").on("slide", function(slideEvt) {
	$("#ex6SliderVal").text(slideEvt.value);
});
$("#ex7").slider();
$("#ex7").on("slide", function(slideEvt) {
	$("#ex7SliderVal").text(slideEvt.value);
});
$("#ex8").slider();
$("#ex8").on("slide", function(slideEvt) {
	$("#ex8SliderVal").text(slideEvt.value);
});